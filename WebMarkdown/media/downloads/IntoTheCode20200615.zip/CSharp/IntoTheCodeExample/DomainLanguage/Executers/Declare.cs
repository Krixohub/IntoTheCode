﻿namespace IntoTheCodeExample.DomainLanguage.Executers
{
    public class Declare
    {
        public DefType TheType;
        public string TheName;
    }
}