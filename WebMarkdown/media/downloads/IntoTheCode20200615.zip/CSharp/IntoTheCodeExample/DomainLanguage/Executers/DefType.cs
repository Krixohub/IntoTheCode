﻿namespace IntoTheCodeExample.DomainLanguage.Executers
{
    public enum DefType
    {
        Void,
        Int,
        String,
        Float,
        Bool
    }
}
