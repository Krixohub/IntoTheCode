﻿using System.Windows.Controls;

namespace TestApp.View
{
    /// <summary>
    /// Interaction logic for CsvDataTab.xaml
    /// </summary>
    public partial class CsvDataTab : UserControl
    {
        public CsvDataTab()
        {
            InitializeComponent();
        }
    }
}
