﻿using System.Windows.Controls;

namespace TestApp.View
{
    /// <summary>
    /// Interaction logic for Expression.xaml
    /// </summary>
    public partial class DomainLanguageTab : UserControl
    {
        public DomainLanguageTab()
        {
            InitializeComponent();
        }
    }
}
