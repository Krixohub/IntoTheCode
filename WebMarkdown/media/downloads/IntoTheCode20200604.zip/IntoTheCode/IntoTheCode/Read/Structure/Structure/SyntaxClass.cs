﻿namespace IntoTheCode.Read.Structure.Structure
{
    //internal abstract class GrammarClass : ElementBase
    //{
    //    //public string Seperator
    //    //{
    //    //    get { return Props.GetValue<string>(() => Seperator); }
    //    //    set { Props.SetValue(() => Seperator, value); }
    //    //}

    //    //public string QuoteString
    //    //{
    //    //    get { return Props.GetValue<string>(() => QuoteString); }
    //    //    set { Props.SetValue(() => QuoteString, value); }
    //    //}

    //    //public ElementStringEscapeStyle EscapeStyle
    //    //{
    //    //    get { return Props.GetValue<ElementStringEscapeStyle>(() => EscapeStyle); }
    //    //    set { Props.SetValue(() => EscapeStyle, value); }
    //    //}
    //}

}
