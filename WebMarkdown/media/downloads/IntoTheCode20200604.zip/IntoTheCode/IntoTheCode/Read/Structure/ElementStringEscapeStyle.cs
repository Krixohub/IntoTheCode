﻿namespace IntoTheCode.Read.Structure
{
    internal enum ElementStringEscapeStyle
    {
        DoublePing,
        BackSlash,
        None,
    }
}
