﻿namespace IntoTheCode.Read.Element.Structure
{
/*

<root>
  <main>
    <a>45</a>
    <b>hej</b>
    <c>4</c>
    <subs/>
  </main>
  <main>
    <a>22</a>
    <b>davb</b>
    <c>7</c>
    <subs>
      <sub>
        <f1>rt</f1> 
        <f2>4</f2> 
        <f3>hg</f3> 
      </sub>
      <sub>
        <f1>er</f1> 
        <f2>5</f2> 
        <f3>hj</f3> 
      </sub>
    </subs>
  </main>
</root>

        IEnumerable<string> a22f3s =
    from item in xmlDoc.Descendants("Item")
    select (string) item.Attribute("PartNumber");
 */
    //class XmlGrammar
    //{
    //}
}
