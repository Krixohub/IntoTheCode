﻿namespace IntoTheCode.Read.Element.Structure
{
    //internal class GrammarAttribute //: GrammarBase
    //{
    //    //public override string GetGrammar() { return ""; }
    //    //public override string Read(int begin, ParserBuffer buffer) { return ""; }

    //    //internal override void LinkSymbols(Parser parser, Func<string, ElementBase> resolver)
    //    //{
    //    //}
    //}
}