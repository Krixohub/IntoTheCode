﻿namespace IntoTheCode.Read.Element
{
    internal enum ElementStringEscapeStyle
    {
        DoublePing,
        BackSlash,
        None,
    }
}
