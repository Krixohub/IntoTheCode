﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IntoTheCode.Buffer
{
    public class LoopLevel
    {
        public int LastInvokePos;
        public int LastInvokeLevel;
    }
}
