﻿using System.Windows;

namespace TestApp.Grammar
{
    /// <summary>
    /// Interaction logic for GrammarLab.xaml
    /// </summary>
    public partial class GrammarEdit : Window
    {
        public GrammarEdit()
        {
            InitializeComponent();
        }
    }
}
