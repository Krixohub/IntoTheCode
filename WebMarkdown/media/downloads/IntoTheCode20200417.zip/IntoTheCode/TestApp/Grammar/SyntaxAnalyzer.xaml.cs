﻿using System.Windows;

namespace TestApp.Grammar
{
    /// <summary>
    /// Interaction logic for GrammarAnalyser.xaml
    /// </summary>
    public partial class GrammarAnalyser : Window
  {
    public GrammarAnalyser()
    {
      InitializeComponent();
    }
  }
}
