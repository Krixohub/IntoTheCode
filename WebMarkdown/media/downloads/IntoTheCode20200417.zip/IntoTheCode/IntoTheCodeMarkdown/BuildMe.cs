﻿using System;

namespace IntoTheCodeMarkdown
{
    public class BuildMe
    {
        public int GetNo()
        {
            return 1;
        }
    }
}
